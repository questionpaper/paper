package com.cts.auto_question_paper.dao;

import java.util.List;

import com.cts.auto_question_paper.bean.Question;

public interface QuestionDAO {
	
	public int addQuestion(Question question);
	public List<Question> getAllQuestion();

}
