package com.cts.auto_question_paper.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cts.auto_question_paper.bean.Question;
import com.cts.auto_question_paper.util.DBUtils;

public class QuestionDAOImpl implements QuestionDAO {
	Question question = new Question();
	private Connection con;
	
	
	@Override
	public List<Question> getAllQuestion() {
		
		List<Question> questions = new ArrayList<Question>();
		PreparedStatement preparedStatement=null;
		String getString ="Select * from question";
	
		ResultSet resultSet= null;
		Question question = null;
		
		try {
			con = DBUtils.getConnection();
			preparedStatement = con.prepareStatement(getString);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()){
				
				String question1 = resultSet.getString("question");
				String option1= resultSet.getString("option1");
				String option2 = resultSet.getString("option2");
				String option3 = resultSet.getString("option3");
				String option4 = resultSet.getString("option4");
				String ans = resultSet.getString("ans");
				
				question = new Question(question1,option1,option2,option3,option4,ans);
			
				questions.add(question);
			}
			return questions;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			DBUtils.closeConnection(con);
		}
		
		return null;
		
	}


	@Override
	public int addQuestion(Question question)
	{
		System.out.println("6");
		String question1=question.getQuestion();
        String option1=question.getOption1();
        String option2=question.getOption2();
        String option3=question.getOption3();
        String option4=question.getOption4();
        String ans =question.getAns();
      
    	System.out.println("7");
         PreparedStatement ps = null;
     	System.out.println("8");
         try
         {
        		System.out.println("9");
                con = DBUtils.getConnection();
            	System.out.println("10");
                //String query = "insert into users(SlNo,fullName,Email,userName,password) values (NULL,?,?,?,?)"; //Insert user details into the table 'USERS'
                String query = "insert into question(question,option1,option2,option3,option4,ans) values (?,?,?,?,?,?)";
            	System.out.println("11");
          ps = con.prepareStatement(query); // generates sql query
      	System.out.println("12");
       ps.setString(1,question1 );
       ps.setString(2, option1);
       ps.setString(3, option2);
       ps.setString(4, option3);
       ps.setString(5, option4);
       ps.setString(6, ans);
      
   	System.out.println("13");
       int i= ps.executeUpdate();
   	System.out.println("14");
                if (i!=0)  //Just to ensure data has been inserted into the database
                return 1; 
    
         }
         
         catch(SQLException e)
         {
                e.printStackTrace();
                return 0;
         }
		return 1;
	}



}
