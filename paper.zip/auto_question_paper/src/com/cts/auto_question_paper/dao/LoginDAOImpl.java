package com.cts.auto_question_paper.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cts.auto_question_paper.bean.Admin;
import com.cts.auto_question_paper.bean.LoginBean;
import com.cts.auto_question_paper.util.DBUtils;

public class LoginDAOImpl implements LoginDAO{

	public boolean validateUser(LoginBean login) {
		// TODO Auto-generated method stub
		Connection connection = null;
		String query = "select * from student where studentId = ? and password = ? ";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1, login.getStudentId());
			preparedStatement.setString(2, login.getPassword());
		
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				return true;
			}
			
			else
				{
				return false;
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		finally {
			DBUtils.closeConnection(connection);
		}
		
	
	}

	@Override
	public boolean validateAdmin(Admin admin) {
		Connection connection = null;
		String query = "select * from login where username = ? and password = ? ";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		
		try {
			connection = DBUtils.getConnection();
			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1, admin.getUserId());
			preparedStatement.setString(2, admin.getPassword());
		
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				
				return true;
			}
			
			else
				{
				return false;
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		finally {
			DBUtils.closeConnection(connection);
		}
		
	}

}
