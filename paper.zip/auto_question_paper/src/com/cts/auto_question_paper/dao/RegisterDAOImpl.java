package com.cts.auto_question_paper.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cts.auto_question_paper.bean.RegisterBean;
import com.cts.auto_question_paper.util.DBUtils;

public class RegisterDAOImpl implements RegisterDAO
{
	public boolean registerUser(RegisterBean bean) {
		// TODO Auto-generated method stub
		Connection connection = null;
		String query = "insert into student values(?,?,?,?,?,?)";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		
		try {
			connection = DBUtils.getConnection();
			
			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1, bean.getStudentId());
			preparedStatement.setString(2, bean.getFirstName());
			preparedStatement.setString(3, bean.getLastName());
			preparedStatement.setString(4, bean.getEmail());
			preparedStatement.setString(5, bean.getPassword());
			preparedStatement.setString(6, bean.getConfirm_password());
			
			
			int i = preparedStatement.executeUpdate();
			
			return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		finally {
			DBUtils.closeConnection(connection);
		}
			}



}


