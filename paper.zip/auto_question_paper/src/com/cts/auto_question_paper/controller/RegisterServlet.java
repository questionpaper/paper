package com.cts.auto_question_paper.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.auto_question_paper.bean.RegisterBean;
import com.cts.auto_question_paper.service.RegisterService;
import com.cts.auto_question_paper.service.RegisterServiceImpl;

/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	RegisterService registerService = new RegisterServiceImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RegisterBean bean = new RegisterBean();
	
		bean.setStudentId(request.getParameter("studentId"));
		bean.setFirstName(request.getParameter("firstName"));
		bean.setLastName(request.getParameter("lastName"));
		bean.setEmail(request.getParameter("email"));
		bean.setPassword(request.getParameter("password"));
		bean.setConfirm_password(request.getParameter("confirm_password"));
	
		System.out.println(bean.toString());
		RequestDispatcher dispatcher = null;
		
		if(registerService.registerUser(bean)) 
		
		{
		
		System.out.println("true");
		dispatcher = request.getRequestDispatcher("loginPage.jsp");
		dispatcher.forward(request, response);
		}
		
		else 
		
		{
			System.out.println("false");
			dispatcher=request.getRequestDispatcher("register.jsp");
			dispatcher.forward(request, response);
		}
		
	}
	
}
