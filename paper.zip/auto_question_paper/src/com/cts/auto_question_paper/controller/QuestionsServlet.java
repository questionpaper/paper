package com.cts.auto_question_paper.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.auto_question_paper.bean.Question;
import com.cts.auto_question_paper.dao.QuestionDAO;
import com.cts.auto_question_paper.dao.QuestionDAOImpl;
import com.cts.auto_question_paper.service.QuestionService;
import com.cts.auto_question_paper.service.QuestionServiceImpl;

/**
 * Servlet implementation class QuestionsServlet
 */
public class QuestionsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	//QuestionService questionService = new QuestionServiceImpl();
      
	QuestionDAO questionDAO = new QuestionDAOImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QuestionsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//HttpSession session = request.getSession();
		System.out.println("QuestionsServlet Working");
	}

}
