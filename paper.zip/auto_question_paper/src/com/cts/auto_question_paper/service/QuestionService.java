package com.cts.auto_question_paper.service;
import java.util.List;

import com.cts.auto_question_paper.bean.Question;
public interface QuestionService {
	
	public int addQuestion(Question question);
	public List<Question> getAllQuestion();



}
