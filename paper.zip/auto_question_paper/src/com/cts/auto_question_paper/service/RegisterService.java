package com.cts.auto_question_paper.service;
import com.cts.auto_question_paper.bean.RegisterBean;

public interface RegisterService {
	public   boolean registerUser(RegisterBean bean) ;
		// TODO Auto-generated method stub
		
	

}
