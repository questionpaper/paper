package com.cts.auto_question_paper.service;

import com.cts.auto_question_paper.bean.Admin;
import com.cts.auto_question_paper.bean.LoginBean;

public interface LoginService {
	public boolean validateUser(LoginBean login);
	public boolean validateAdmin(Admin admin);
}
